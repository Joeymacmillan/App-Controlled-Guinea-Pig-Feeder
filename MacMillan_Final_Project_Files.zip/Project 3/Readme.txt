There are 4 folders for this project

- App creation 
	Contains information about what website to use to create the app

- Enclosure
	Contains the two stl files for the enclosure

-Hardware
	Contains the BOM to create the project as well as other necessary   	components

-Software
	Contains the Arduino code for the project
	Contains the aia project file for the app that was created through 	MIT app inventor