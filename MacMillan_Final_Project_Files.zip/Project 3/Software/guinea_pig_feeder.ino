#include <ESP8266WiFi.h>

#define IN1a 15
#define IN2a 13
#define IN3a 12
#define IN4a 14

int delayTime = 2;

WiFiClient client;
WiFiServer server(80);

const char* ssid = "WIRELESS-PITTNET";
const char* password = "$wamp3Dog";

String data = "";

void setup() {
  pinMode(IN1a, OUTPUT);
  pinMode(IN2a, OUTPUT);
  pinMode(IN3a, OUTPUT);
  pinMode(IN4a, OUTPUT);
  
  Serial.begin(115200);
  connectWiFi();
  server.begin();
}

void loop() {
  client = server.available();
  if (!client) return;
  
  data = checkClient();
  
  if (data == "feed") {
    // Small - rotates forward and backward
    feedPet(50);
  }
  else if (data == "feed2") {
    // Medium - just spin forward and stop
    forwardOnlyFeed(200);
  }
  else if (data == "feed3") {
    // Large - spin forward more and stop
    forwardOnlyFeed(400);
  }
}

// Original function that goes forward then backward
void feedPet(int steps) {
  // Forward rotation
  for (int i = 0; i < steps; i++) {
    Serial.println("FORWARD");
    forwardMotor();
  }
  
  delay(200);
  
  // Backward rotation
  for (int i = 0; i < steps; i++) {
    Serial.println("BACKWARD");
    backwardMotor();
  }
  
  stopMotor();
}

// New function for one-direction feeding
void forwardOnlyFeed(int steps) {
  // Forward rotation only
  for (int i = 0; i < steps; i++) {
    Serial.println("FORWARD");
    forwardMotor();
  }
  
  stopMotor();
}

void connectWiFi() {
  Serial.println("Connecting to WIFI");
  WiFi.begin(ssid, password);
  while ((!(WiFi.status() == WL_CONNECTED))) {
    delay(300);
    Serial.print("..");
  }
  Serial.println("");
  Serial.println("WiFi connected");
  Serial.println("Wemos Local IP is : ");
  Serial.print((WiFi.localIP()));
  Serial.print("");
  Serial.println("");
}

String checkClient (void) {
  while (!client.available()) delay(1);
  String request = client.readStringUntil('\r');
  request.remove(0, 5);
  request.remove(request.length() - 9, 9);
  return request;
}

void forwardMotor(void) {
  digitalWrite(IN4a, HIGH);
  digitalWrite(IN3a, LOW);
  digitalWrite(IN2a, LOW);
  digitalWrite(IN1a, LOW);
  delay(delayTime);
  
  digitalWrite(IN4a, LOW);
  digitalWrite(IN3a, HIGH);
  digitalWrite(IN2a, LOW);
  digitalWrite(IN1a, LOW);
  delay(delayTime);
  
  digitalWrite(IN4a, LOW);
  digitalWrite(IN3a, LOW);
  digitalWrite(IN2a, HIGH);
  digitalWrite(IN1a, LOW);
  delay(delayTime);
  
  digitalWrite(IN4a, LOW);
  digitalWrite(IN3a, LOW);
  digitalWrite(IN2a, LOW);
  digitalWrite(IN1a, HIGH);
  delay(delayTime);
}

void backwardMotor(void) {
  digitalWrite(IN4a, LOW);
  digitalWrite(IN3a, LOW);
  digitalWrite(IN2a, LOW);
  digitalWrite(IN1a, HIGH);
  delay(delayTime);
  
  digitalWrite(IN4a, LOW);
  digitalWrite(IN3a, LOW);
  digitalWrite(IN2a, HIGH);
  digitalWrite(IN1a, LOW);
  delay(delayTime);
  
  digitalWrite(IN4a, LOW);
  digitalWrite(IN3a, HIGH);
  digitalWrite(IN2a, LOW);
  digitalWrite(IN1a, LOW);
  delay(delayTime);
  
  digitalWrite(IN4a, HIGH);
  digitalWrite(IN3a, LOW);
  digitalWrite(IN2a, LOW);
  digitalWrite(IN1a, LOW);
  delay(delayTime);
}

void stopMotor(void) {
  digitalWrite(IN4a, LOW);
  digitalWrite(IN3a, LOW);
  digitalWrite(IN2a, LOW);
  digitalWrite(IN1a, LOW);
}